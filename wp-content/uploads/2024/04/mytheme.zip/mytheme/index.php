<?php get_header(); ?>

<div class="container mx-auto py-8">
    <!-- Include the loan calculator shortcode here -->
    <?php echo do_shortcode('[loan_calculator]'); ?>
</div>

<?php get_footer(); ?>